#include "components.h"
#include "graphics.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

/* ===== StatusBar ===== */

StatusBar* statusbar_create(int height) {
    StatusBar* bar = (StatusBar*)malloc(sizeof(StatusBar));
    bar->height = height;
    bar->bg_color = COLOR_PRIMARY;
    bar->show_time = true;
    bar->show_battery = true;
    bar->show_signal = true;
    return bar;
}

void statusbar_draw(StatusBar* bar, int width) {
    Rect bg = {0, 0, width, bar->height};
    graphics_draw_rect(bg, bar->bg_color, true);
    
    time_t now = time(NULL);
    struct tm* timeinfo = localtime(&now);
    char time_str[16];
    strftime(time_str, sizeof(time_str), "%H:%M", timeinfo);
    
    graphics_draw_text(time_str, 20, 15, COLOR_WHITE);
    
    if (bar->show_battery) {
        graphics_draw_text("100%", width - 80, 15, COLOR_WHITE);
    }
}

void statusbar_update(StatusBar* bar) {
    /* Обновление информации статус-бара */
}

void statusbar_free(StatusBar* bar) {
    free(bar);
}

/* ===== NavigationBar ===== */

NavigationBar* navbar_create(const char** items, int count, int height) {
    NavigationBar* bar = (NavigationBar*)malloc(sizeof(NavigationBar));
    bar->items = items;
    bar->item_count = count;
    bar->selected_index = 0;
    bar->height = height;
    bar->bg_color = COLOR_WHITE;
    bar->fg_color = COLOR_TEXT;
    return bar;
}

void navbar_draw(NavigationBar* bar, int width) {
    Rect bg = {0, 0, width, bar->height};
    graphics_draw_rect(bg, bar->bg_color, true);
    graphics_draw_rect(bg, COLOR_BORDER, false);
    
    int item_width = width / bar->item_count;
    
    for (int i = 0; i < bar->item_count; i++) {
        int x = i * item_width;
        int text_w = graphics_get_text_width(bar->items[i]);
        int text_x = x + (item_width - text_w) / 2;
        
        Color color = (i == bar->selected_index) ? COLOR_PRIMARY : bar->fg_color;
        graphics_draw_text(bar->items[i], text_x, 10, color);
        
        if (i == bar->selected_index) {
            Rect underline = {x, bar->height - 3, item_width, 3};
            graphics_draw_rect(underline, COLOR_PRIMARY, true);
        }
    }
}

void navbar_handle_click(NavigationBar* bar, int x, int y) {
    if (y < 0 || y > bar->height) return;
    
    int width = graphics_get_width();
    int item_width = width / bar->item_count;
    int index = x / item_width;
    
    if (index >= 0 && index < bar->item_count) {
        bar->selected_index = index;
    }
}

void navbar_free(NavigationBar* bar) {
    free(bar);
}

/* ===== Dialog ===== */

Dialog* dialog_create(const char* title, const char* message) {
    Dialog* dlg = (Dialog*)malloc(sizeof(Dialog));
    dlg->title = title;
    dlg->message = message;
    dlg->ok_text = "OK";
    dlg->cancel_text = "Cancel";
    dlg->visible = false;
    dlg->on_ok = NULL;
    dlg->on_cancel = NULL;
    return dlg;
}

void dialog_show(Dialog* dialog) {
    dialog->visible = true;
}

void dialog_hide(Dialog* dialog) {
    dialog->visible = false;
}

void dialog_draw(Dialog* dialog, int width, int height) {
    if (!dialog->visible) return;
    
    int dlg_width = 400;
    int dlg_height = 250;
    int dlg_x = (width - dlg_width) / 2;
    int dlg_y = (height - dlg_height) / 2;
    
    /* Фон диалога */
    Rect dlg_bg = {dlg_x, dlg_y, dlg_width, dlg_height};
    graphics_draw_rect(dlg_bg, COLOR_WHITE, true);
    graphics_draw_rect(dlg_bg, COLOR_BORDER, false);
    
    /* Заголовок */
    graphics_draw_text(dialog->title, dlg_x + 20, dlg_y + 20, COLOR_TEXT);
    
    /* Сообщение */
    graphics_draw_text(dialog->message, dlg_x + 20, dlg_y + 70, COLOR_TEXT);
    
    /* Кнопки */
    int btn_width = 150;
    int btn_height = 40;
    int btn_y = dlg_y + dlg_height - 60;
    
    /* OK кнопка */
    Rect ok_btn = {dlg_x + 30, btn_y, btn_width, btn_height};
    graphics_draw_rect(ok_btn, COLOR_PRIMARY, true);
    graphics_draw_text(dialog->ok_text, dlg_x + 80, btn_y + 10, COLOR_WHITE);
    
    /* Cancel кнопка */
    Rect cancel_btn = {dlg_x + dlg_width - btn_width - 30, btn_y, btn_width, btn_height};
    graphics_draw_rect(cancel_btn, COLOR_BORDER, true);
    graphics_draw_text(dialog->cancel_text, dlg_x + dlg_width - 130, btn_y + 10, COLOR_TEXT);
}

void dialog_free(Dialog* dialog) {
    free(dialog);
}

/* ===== Notification ===== */

Notification* notification_create(const char* message, int duration) {
    Notification* notif = (Notification*)malloc(sizeof(Notification));
    notif->message = message;
    notif->duration = duration;
    notif->elapsed = 0;
    notif->bg_color = COLOR_PRIMARY;
    notif->visible = false;
    return notif;
}

void notification_show(Notification* notif) {
    notif->visible = true;
    notif->elapsed = 0;
}

void notification_update(Notification* notif) {
    if (notif->visible) {
        notif->elapsed++;
        if (notif->elapsed >= notif->duration * 60) {
            notif->visible = false;
        }
    }
}

void notification_draw(Notification* notif, int width, int height) {
    if (!notif->visible) return;
    
    int notif_height = 60;
    int notif_y = height - notif_height - 20;
    
    Rect notif_bg = {20, notif_y, width - 40, notif_height};
    graphics_draw_rect(notif_bg, notif->bg_color, true);
    graphics_draw_rect(notif_bg, COLOR_BORDER, false);
    
    graphics_draw_text(notif->message, 40, notif_y + 20, COLOR_WHITE);
}

void notification_free(Notification* notif) {
    free(notif);
}

/* ===== ProgressBar ===== */

ProgressBar* progressbar_create(int x, int y, int w, int h, int max_value) {
    ProgressBar* pb = (ProgressBar*)malloc(sizeof(ProgressBar));
    pb->x = x;
    pb->y = y;
    pb->w = w;
    pb->h = h;
    pb->value = 0;
    pb->max_value = max_value;
    pb->bg_color = COLOR_BORDER;
    pb->fill_color = COLOR_PRIMARY;
    return pb;
}

void progressbar_set_value(ProgressBar* pb, int value) {
    if (value < 0) value = 0;
    if (value > pb->max_value) value = pb->max_value;
    pb->value = value;
}

void progressbar_draw(ProgressBar* pb) {
    Rect bg = {pb->x, pb->y, pb->w, pb->h};
    graphics_draw_rect(bg, pb->bg_color, true);
    
    int filled_width = (pb->w * pb->value) / pb->max_value;
    Rect fill = {pb->x, pb->y, filled_width, pb->h};
    graphics_draw_rect(fill, pb->fill_color, true);
}

void progressbar_free(ProgressBar* pb) {
    free(pb);
}
