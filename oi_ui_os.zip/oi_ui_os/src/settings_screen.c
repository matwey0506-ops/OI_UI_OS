#include "ui.h"
#include "graphics.h"
#include "kernel.h"
#include <stdio.h>
#include <string.h>

/* Структура пункта меню */
typedef struct {
    const char* title;
    const char* icon;
    const char* value;
    int type; /* 0=text, 1=toggle, 2=slider */
} MenuItem;

/* Пункты меню настроек */
static MenuItem menu_items[] = {
    {"Display", "🖥️", "Brightness", 2},
    {"Sound", "🔊", "Volume", 2},
    {"Wi-Fi", "📶", "Connected", 1},
    {"Bluetooth", "🔵", "Off", 1},
    {"Airplane Mode", "✈️", "Off", 1},
    {"Battery", "🔋", "85%", 0},
    {"Storage", "💾", "32GB/64GB", 0},
    {"About", "ℹ️", "OI UI v1.0", 0}
};

static int menu_items_count = 8;
static int scroll_offset = 0;

/* Обработчик клика на пункт меню */
void settings_menu_item_clicked(UIElement* elem) {
    printf("[SETTINGS] Menu item clicked: %s\n", elem->label);
}

/* Обработчик переключателя */
void settings_toggle_clicked(UIElement* elem) {
    bool* state = (bool*)elem->data;
    *state = !(*state);
    elem->bg_color = *state ? COLOR_PRIMARY : COLOR_BORDER;
    printf("[SETTINGS] Toggle: %s -> %s\n", elem->label, *state ? "ON" : "OFF");
}

/* Обработчик слайдера */
void settings_slider_clicked(UIElement* elem) {
    printf("[SETTINGS] Slider: %s\n", elem->label);
}

/* Обработчик экрана настроек */
void settings_screen_on_show() {
    printf("[SETTINGS] Settings screen shown\n");
}

void settings_screen_on_hide() {
    printf("[SETTINGS] Settings screen hidden\n");
}

void settings_screen_on_touch(int x, int y) {
    printf("[SETTINGS] Touch at: %d, %d\n", x, y);
}

void settings_screen_on_update() {
    kernel_update_system_info();
}

/* Отрисовка заголовка */
void settings_draw_header(int width) {
    /* Фон заголовка */
    Rect header = {0, 0, width, 70};
    graphics_draw_rect(header, COLOR_PRIMARY, true);
    
    /* Кнопка "Назад" */
    graphics_draw_text("< Back", 20, 20, COLOR_WHITE);
    
    /* Название */
    graphics_draw_text("Settings", width / 2 - 40, 20, COLOR_WHITE);
}

/* Отрисовка экрана настроек */
void settings_screen_draw() {
    int width = graphics_get_width();
    int height = graphics_get_height();
    
    /* Фон */
    graphics_clear(COLOR_BACKGROUND);
    
    /* Заголовок */
    settings_draw_header(width);
    
    /* Пункты меню */
    int item_height = 60;
    int start_y = 80;
    int visible_items = (height - start_y - 50) / item_height;
    
    for (int i = 0; i < visible_items && i + scroll_offset < menu_items_count; i++) {
        MenuItem* item = &menu_items[i + scroll_offset];
        int y = start_y + i * item_height;
        
        /* Фон пункта */
        Rect item_bg = {0, y, width, item_height};
        graphics_draw_rect(item_bg, COLOR_WHITE, true);
        
        /* Разделитель */
        graphics_draw_line(0, y + item_height, width, y + item_height, COLOR_BORDER, 1);
        
        /* Иконка */
        graphics_draw_text(item->icon, 20, y + 15, COLOR_TEXT);
        
        /* Название */
        graphics_draw_text(item->title, 70, y + 10, COLOR_TEXT);
        
        /* Значение */
        int value_x = width - graphics_get_text_width(item->value) - 20;
        
        if (item->type == 0) {
            /* Текст */
            graphics_draw_text(item->value, value_x, y + 15, COLOR_TEXT);
        } else if (item->type == 1) {
            /* Переключатель */
            Rect toggle_bg = {value_x - 50, y + 12, 50, 30};
            Color toggle_color = strcmp(item->value, "On") == 0 ? COLOR_PRIMARY : COLOR_BORDER;
            graphics_draw_rect(toggle_bg, toggle_color, true);
            graphics_draw_rect(toggle_bg, COLOR_BORDER, false);
            
            /* Кружок переключателя */
            int circle_x = strcmp(item->value, "On") == 0 ? value_x - 20 : value_x - 50 + 10;
            graphics_draw_circle(circle_x, y + 27, 10, COLOR_WHITE, true);
        } else if (item->type == 2) {
            /* Слайдер */
            Rect slider_bg = {value_x - 100, y + 20, 100, 6};
            graphics_draw_rect(slider_bg, COLOR_BORDER, true);
            
            /* Заполненная часть слайдера */
            Rect slider_fill = {value_x - 100, y + 20, 70, 6};
            graphics_draw_rect(slider_fill, COLOR_PRIMARY, true);
            
            /* Ползунок */
            graphics_draw_circle(value_x - 30, y + 23, 8, COLOR_PRIMARY, true);
        }
    }
    
    /* Информация о системе */
    SystemInfo* sys_info = kernel_get_system_info();
    char info_str[128];
    snprintf(info_str, sizeof(info_str), 
             "Memory: %u MB | Battery: %.0f%%",
             sys_info->free_memory / (1024 * 1024),
             sys_info->battery_level);
    
    graphics_draw_text(info_str, 20, height - 30, COLOR_TEXT);
}

/* Создание экрана настроек */
Screen* settings_screen_create() {
    Screen* screen = ui_create_screen("Settings");
    screen->bg_color = COLOR_BACKGROUND;
    screen->on_show = settings_screen_on_show;
    screen->on_hide = settings_screen_on_hide;
    screen->on_touch = settings_screen_on_touch;
    screen->on_update = settings_screen_on_update;
    
    printf("[SETTINGS] Settings screen created\n");
    
    return screen;
}

/* Получение функции отрисовки */
void (*settings_screen_get_draw_func())() {
    return settings_screen_draw;
}

/* Прокрутка меню */
void settings_screen_scroll(int direction) {
    scroll_offset += direction;
    if (scroll_offset < 0) scroll_offset = 0;
    if (scroll_offset > menu_items_count - 4) scroll_offset = menu_items_count - 4;
}
