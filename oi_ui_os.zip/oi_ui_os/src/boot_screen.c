#include "ui.h"
#include "graphics.h"
#include "kernel.h"
#include <stdio.h>
#include <unistd.h>
#include <time.h>

/* Глобальные переменные для экрана загрузки */
static int boot_progress = 0;
static int boot_stage = 0;
static time_t boot_start_time;

typedef struct {
    const char* message;
    int duration;
} BootStage;

static BootStage boot_stages[] = {
    {"Initializing kernel...", 1},
    {"Loading drivers...", 1},
    {"Mounting filesystems...", 1},
    {"Starting services...", 1},
    {"Loading UI framework...", 1},
    {"Preparing display...", 1},
    {"Boot complete!", 2}
};

static int boot_stages_count = 7;

/* Обработчик экрана загрузки */
void boot_screen_update() {
    time_t current_time = time(NULL);
    int elapsed = (int)(current_time - boot_start_time);
    
    /* Вычисление прогресса */
    boot_progress = (elapsed * 100) / 8;
    if (boot_progress > 100) boot_progress = 100;
    
    /* Определение текущего этапа */
    boot_stage = elapsed;
    if (boot_stage >= boot_stages_count) boot_stage = boot_stages_count - 1;
}

/* Отрисовка экрана загрузки */
void boot_screen_draw() {
    int width = graphics_get_width();
    int height = graphics_get_height();
    
    /* Фон */
    graphics_clear(COLOR_PRIMARY);
    
    /* Логотип ОС */
    int logo_y = height / 3;
    graphics_draw_circle(width / 2, logo_y, 60, COLOR_WHITE, true);
    graphics_draw_text("OI", width / 2 - 20, logo_y - 15, COLOR_PRIMARY);
    
    /* Название ОС */
    graphics_draw_text("OI UI Operating System", width / 2 - 120, logo_y + 100, COLOR_WHITE);
    graphics_draw_text("v1.0", width / 2 - 20, logo_y + 130, COLOR_WHITE);
    
    /* Текущий этап загрузки */
    if (boot_stage < boot_stages_count) {
        graphics_draw_text(boot_stages[boot_stage].message, 
                          width / 2 - 100, height / 2 + 50, COLOR_WHITE);
    }
    
    /* Полоса прогресса */
    int progress_bar_width = 300;
    int progress_bar_height = 8;
    int progress_bar_x = (width - progress_bar_width) / 2;
    int progress_bar_y = height / 2 + 120;
    
    /* Фон полосы */
    Rect progress_bg = {progress_bar_x, progress_bar_y, progress_bar_width, progress_bar_height};
    graphics_draw_rect(progress_bg, COLOR_WHITE, true);
    
    /* Заполненная часть */
    int filled_width = (progress_bar_width * boot_progress) / 100;
    Rect progress_fill = {progress_bar_x, progress_bar_y, filled_width, progress_bar_height};
    graphics_draw_rect(progress_fill, COLOR_ACCENT, true);
    
    /* Процент */
    char progress_text[16];
    snprintf(progress_text, sizeof(progress_text), "%d%%", boot_progress);
    graphics_draw_text(progress_text, width / 2 - 15, progress_bar_y + 20, COLOR_WHITE);
    
    /* Версия ядра */
    graphics_draw_text("Kernel: " OS_VERSION, 10, height - 30, COLOR_WHITE);
}

/* Инициализация экрана загрузки */
Screen* boot_screen_create() {
    boot_start_time = time(NULL);
    boot_progress = 0;
    boot_stage = 0;
    
    Screen* screen = ui_create_screen("Boot Screen");
    screen->bg_color = COLOR_PRIMARY;
    
    printf("[BOOT] Boot screen initialized\n");
    
    return screen;
}

/* Обновление экрана загрузки */
void boot_screen_on_update() {
    boot_screen_update();
}

/* Отрисовка экрана загрузки */
void boot_screen_on_draw() {
    boot_screen_draw();
}

/* Проверка завершения загрузки */
bool boot_screen_is_complete() {
    return boot_progress >= 100;
}

/* Получение времени загрузки */
int boot_screen_get_progress() {
    return boot_progress;
}
