#include "kernel.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* Глобальные переменные */
static SystemInfo g_system_info;
static DeviceInfo g_device_info;
static Process* g_processes = NULL;
static uint32_t g_process_count = 0;
static uint32_t g_next_pid = 1000;
static time_t g_boot_time;

/* Инициализация ядра */
void kernel_init() {
    /* Инициализация системной информации */
    strcpy(g_system_info.os_name, OS_NAME);
    strcpy(g_system_info.os_version, OS_VERSION);
    g_system_info.total_memory = 2048 * 1024 * 1024; /* 2GB */
    g_system_info.free_memory = g_system_info.total_memory;
    g_system_info.cpu_usage = 0;
    g_system_info.battery_level = 100.0f;
    g_system_info.charging = false;
    g_system_info.temperature = 35.5f;
    
    /* Инициализация информации об устройстве */
    g_device_info.screen_width = 1080;
    g_device_info.screen_height = 1920;
    g_device_info.screen_dpi = 420;
    g_device_info.touchscreen = true;
    g_device_info.accelerometer = true;
    g_device_info.gyroscope = true;
    g_device_info.brightness = 1.0f;
    g_device_info.wifi_enabled = true;
    g_device_info.bluetooth_enabled = true;
    g_device_info.airplane_mode = false;
    
    /* Инициализация процессов */
    g_processes = (Process*)malloc(sizeof(Process) * 64);
    g_process_count = 0;
    
    /* Запись времени загрузки */
    g_boot_time = time(NULL);
    
    printf("[KERNEL] OI UI Operating System initialized\n");
    printf("[KERNEL] Version: %s\n", OS_VERSION);
    printf("[KERNEL] Device: %dx%d, %d DPI\n", 
           g_device_info.screen_width, 
           g_device_info.screen_height,
           g_device_info.screen_dpi);
}

/* Получение информации о системе */
SystemInfo* kernel_get_system_info() {
    return &g_system_info;
}

/* Получение информации об устройстве */
DeviceInfo* kernel_get_device_info() {
    return &g_device_info;
}

/* Обновление системной информации */
void kernel_update_system_info() {
    g_system_info.uptime_seconds = (uint32_t)(time(NULL) - g_boot_time);
    
    /* Симуляция использования батареи */
    if (!g_system_info.charging && g_system_info.battery_level > 0) {
        g_system_info.battery_level -= 0.001f;
    } else if (g_system_info.charging && g_system_info.battery_level < 100.0f) {
        g_system_info.battery_level += 0.01f;
    }
    
    /* Симуляция использования CPU */
    g_system_info.cpu_usage = (uint32_t)(g_process_count * 5);
    if (g_system_info.cpu_usage > 100) g_system_info.cpu_usage = 100;
    
    /* Симуляция использования памяти */
    g_system_info.free_memory = g_system_info.total_memory - (g_process_count * 50 * 1024 * 1024);
}

/* Создание процесса */
uint32_t kernel_create_process(const char* name) {
    if (g_process_count >= 64) return 0;
    
    Process* proc = &g_processes[g_process_count];
    proc->pid = g_next_pid++;
    strncpy(proc->name, name, 63);
    proc->name[63] = '\0';
    proc->memory_usage = 50 * 1024 * 1024; /* 50MB */
    proc->priority = 5;
    proc->state = 1; /* running */
    
    g_process_count++;
    
    printf("[KERNEL] Process created: %s (PID: %u)\n", name, proc->pid);
    return proc->pid;
}

/* Завершение процесса */
void kernel_kill_process(uint32_t pid) {
    for (uint32_t i = 0; i < g_process_count; i++) {
        if (g_processes[i].pid == pid) {
            printf("[KERNEL] Process killed: %s (PID: %u)\n", g_processes[i].name, pid);
            
            /* Сдвиг массива */
            for (uint32_t j = i; j < g_process_count - 1; j++) {
                g_processes[j] = g_processes[j + 1];
            }
            g_process_count--;
            return;
        }
    }
}

/* Пауза процесса */
void kernel_pause_process(uint32_t pid) {
    for (uint32_t i = 0; i < g_process_count; i++) {
        if (g_processes[i].pid == pid) {
            g_processes[i].state = 2; /* paused */
            printf("[KERNEL] Process paused: %s (PID: %u)\n", g_processes[i].name, pid);
            return;
        }
    }
}

/* Возобновление процесса */
void kernel_resume_process(uint32_t pid) {
    for (uint32_t i = 0; i < g_process_count; i++) {
        if (g_processes[i].pid == pid) {
            g_processes[i].state = 1; /* running */
            printf("[KERNEL] Process resumed: %s (PID: %u)\n", g_processes[i].name, pid);
            return;
        }
    }
}

/* Выделение памяти */
void* kernel_malloc(size_t size) {
    return malloc(size);
}

/* Освобождение памяти */
void kernel_free(void* ptr) {
    free(ptr);
}

/* Установка яркости */
void kernel_set_brightness(float level) {
    if (level < 0.0f) level = 0.0f;
    if (level > 1.0f) level = 1.0f;
    g_device_info.brightness = level;
    printf("[KERNEL] Brightness set to: %.1f%%\n", level * 100.0f);
}

/* Переход в режим сна */
void kernel_sleep() {
    printf("[KERNEL] System entering sleep mode...\n");
}

/* Пробуждение системы */
void kernel_wake() {
    printf("[KERNEL] System waking up...\n");
}
