#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <SDL2/SDL.h>
#include "kernel.h"
#include "graphics.h"
#include "ui.h"

/* Объявления функций из других модулей */
Screen* boot_screen_create();
bool boot_screen_is_complete();
int boot_screen_get_progress();
void boot_screen_on_update();
void boot_screen_on_draw();

Screen* home_screen_create();
void (*home_screen_get_draw_func())();

Screen* settings_screen_create();
void (*settings_screen_get_draw_func())();

/* Глобальные переменные */
static Screen* g_boot_screen = NULL;
static Screen* g_home_screen = NULL;
static Screen* g_settings_screen = NULL;
static Screen* g_current_screen = NULL;

static bool g_running = true;
static bool g_boot_complete = false;

static void (*g_current_draw_func)() = NULL;

/* Обработка событий */
void handle_events() {
    SDL_Event event;
    
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_QUIT:
                g_running = false;
                break;
            
            case SDL_FINGERDOWN: {
                int x = (int)(event.tfinger.x * graphics_get_width());
                int y = (int)(event.tfinger.y * graphics_get_height());
                ui_handle_touch(x, y);
                printf("[MAIN] Touch down: %d, %d\n", x, y);
                break;
            }
            
            case SDL_FINGERUP: {
                int x = (int)(event.tfinger.x * graphics_get_width());
                int y = (int)(event.tfinger.y * graphics_get_height());
                ui_handle_release(x, y);
                printf("[MAIN] Touch up: %d, %d\n", x, y);
                break;
            }
            
            case SDL_FINGERMOTION: {
                int x = (int)(event.tfinger.x * graphics_get_width());
                int y = (int)(event.tfinger.y * graphics_get_height());
                ui_handle_motion(x, y);
                break;
            }
            
            case SDL_MOUSEBUTTONDOWN: {
                ui_handle_touch(event.button.x, event.button.y);
                printf("[MAIN] Mouse down: %d, %d\n", event.button.x, event.button.y);
                break;
            }
            
            case SDL_MOUSEBUTTONUP: {
                ui_handle_release(event.button.x, event.button.y);
                printf("[MAIN] Mouse up: %d, %d\n", event.button.x, event.button.y);
                break;
            }
            
            case SDL_MOUSEMOTION: {
                ui_handle_motion(event.motion.x, event.motion.y);
                break;
            }
            
            case SDL_KEYDOWN:
                if (event.key.keysym.sym == SDLK_ESCAPE) {
                    g_running = false;
                }
                break;
            
            default:
                break;
        }
    }
}

/* Обновление логики */
void update() {
    if (!g_boot_complete) {
        boot_screen_on_update();
        
        if (boot_screen_is_complete()) {
            g_boot_complete = true;
            printf("[MAIN] Boot complete, switching to home screen\n");
            ui_show_screen(g_home_screen);
            g_current_screen = g_home_screen;
            g_current_draw_func = home_screen_get_draw_func();
        }
    } else if (g_current_screen) {
        if (g_current_screen->on_update) {
            g_current_screen->on_update();
        }
    }
}

/* Отрисовка */
void render() {
    if (!g_boot_complete) {
        boot_screen_on_draw();
    } else if (g_current_draw_func) {
        g_current_draw_func();
    }
    
    graphics_present();
}

/* Инициализация ОС */
bool os_init() {
    printf("=== OI UI Operating System ===\n");
    printf("Initializing...\n\n");
    
    /* Инициализация ядра */
    kernel_init();
    
    /* Инициализация графики */
    if (!graphics_init(1080, 1920, "OI UI - Touch Operating System")) {
        printf("[ERROR] Graphics initialization failed\n");
        return false;
    }
    
    /* Загрузка шрифта */
    if (!graphics_load_font("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)) {
        printf("[WARNING] Default font not found, using system font\n");
    }
    
    /* Инициализация UI системы */
    ui_init();
    
    /* Создание экранов */
    g_boot_screen = boot_screen_create();
    g_home_screen = home_screen_create();
    g_settings_screen = settings_screen_create();
    
    /* Показ экрана загрузки */
    ui_show_screen(g_boot_screen);
    g_current_screen = g_boot_screen;
    g_current_draw_func = boot_screen_on_draw;
    
    printf("[MAIN] OI UI Operating System initialized successfully\n\n");
    
    return true;
}

/* Завершение работы ОС */
void os_shutdown() {
    printf("\n[MAIN] Shutting down OI UI Operating System...\n");
    graphics_quit();
    printf("[MAIN] Goodbye!\n");
}

/* Главная функция */
int main(int argc, char* argv[]) {
    /* Инициализация ОС */
    if (!os_init()) {
        printf("[ERROR] Failed to initialize OI UI Operating System\n");
        return 1;
    }
    
    /* Главный цикл */
    printf("[MAIN] Entering main loop\n\n");
    
    while (g_running) {
        handle_events();
        update();
        render();
        
        /* FPS контроль */
        SDL_Delay(16); /* ~60 FPS */
    }
    
    /* Завершение работы */
    os_shutdown();
    
    return 0;
}
