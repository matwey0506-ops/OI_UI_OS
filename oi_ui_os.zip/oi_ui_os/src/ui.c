#include "ui.h"
#include "graphics.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* Глобальные переменные */
static Screen* g_current_screen = NULL;
static Screen** g_screens = NULL;
static uint32_t g_screen_count = 0;

/* Инициализация UI системы */
void ui_init() {
    g_screens = (Screen**)malloc(sizeof(Screen*) * 16);
    g_screen_count = 0;
    printf("[UI] UI system initialized\n");
}

/* Создание кнопки */
UIElement* ui_create_button(int x, int y, int w, int h, const char* label) {
    UIElement* btn = (UIElement*)malloc(sizeof(UIElement));
    btn->type = UI_BUTTON;
    btn->bounds = (Rect){x, y, w, h};
    btn->bg_color = COLOR_PRIMARY;
    btn->fg_color = COLOR_WHITE;
    btn->visible = true;
    btn->enabled = true;
    btn->focused = false;
    strncpy(btn->label, label, 255);
    btn->label[255] = '\0';
    btn->on_click = NULL;
    btn->on_draw = NULL;
    btn->data = NULL;
    return btn;
}

/* Создание метки */
UIElement* ui_create_label(int x, int y, const char* text) {
    UIElement* lbl = (UIElement*)malloc(sizeof(UIElement));
    lbl->type = UI_LABEL;
    lbl->bounds = (Rect){x, y, 0, 0};
    lbl->bg_color = COLOR_BACKGROUND;
    lbl->fg_color = COLOR_TEXT;
    lbl->visible = true;
    lbl->enabled = true;
    lbl->focused = false;
    strncpy(lbl->label, text, 255);
    lbl->label[255] = '\0';
    lbl->on_click = NULL;
    lbl->on_draw = NULL;
    lbl->data = NULL;
    return lbl;
}

/* Создание иконки */
UIElement* ui_create_icon(int x, int y, int size, const char* icon_name) {
    UIElement* icon = (UIElement*)malloc(sizeof(UIElement));
    icon->type = UI_ICON;
    icon->bounds = (Rect){x, y, size, size};
    icon->bg_color = COLOR_BACKGROUND;
    icon->fg_color = COLOR_TEXT;
    icon->visible = true;
    icon->enabled = true;
    icon->focused = false;
    strncpy(icon->label, icon_name, 255);
    icon->label[255] = '\0';
    icon->on_click = NULL;
    icon->on_draw = NULL;
    icon->data = NULL;
    return icon;
}

/* Создание слайдера */
UIElement* ui_create_slider(int x, int y, int w, int min_val, int max_val) {
    UIElement* slider = (UIElement*)malloc(sizeof(UIElement));
    slider->type = UI_SLIDER;
    slider->bounds = (Rect){x, y, w, 20};
    slider->bg_color = COLOR_BORDER;
    slider->fg_color = COLOR_PRIMARY;
    slider->visible = true;
    slider->enabled = true;
    slider->focused = false;
    slider->label[0] = '\0';
    slider->on_click = NULL;
    slider->on_draw = NULL;
    
    int* range = (int*)malloc(sizeof(int) * 2);
    range[0] = min_val;
    range[1] = max_val;
    slider->data = range;
    
    return slider;
}

/* Создание переключателя */
UIElement* ui_create_toggle(int x, int y, bool initial_state) {
    UIElement* toggle = (UIElement*)malloc(sizeof(UIElement));
    toggle->type = UI_TOGGLE;
    toggle->bounds = (Rect){x, y, 50, 30};
    toggle->bg_color = initial_state ? COLOR_PRIMARY : COLOR_BORDER;
    toggle->fg_color = COLOR_WHITE;
    toggle->visible = true;
    toggle->enabled = true;
    toggle->focused = false;
    toggle->label[0] = '\0';
    toggle->on_click = NULL;
    toggle->on_draw = NULL;
    
    bool* state = (bool*)malloc(sizeof(bool));
    *state = initial_state;
    toggle->data = state;
    
    return toggle;
}

/* Создание панели */
UIElement* ui_create_panel(int x, int y, int w, int h) {
    UIElement* panel = (UIElement*)malloc(sizeof(UIElement));
    panel->type = UI_PANEL;
    panel->bounds = (Rect){x, y, w, h};
    panel->bg_color = COLOR_WHITE;
    panel->fg_color = COLOR_TEXT;
    panel->visible = true;
    panel->enabled = true;
    panel->focused = false;
    panel->label[0] = '\0';
    panel->on_click = NULL;
    panel->on_draw = NULL;
    panel->data = NULL;
    return panel;
}

/* Создание экрана */
Screen* ui_create_screen(const char* name) {
    Screen* screen = (Screen*)malloc(sizeof(Screen));
    strncpy(screen->name, name, 63);
    screen->name[63] = '\0';
    screen->elements = (UIElement**)malloc(sizeof(UIElement*) * 64);
    screen->element_count = 0;
    screen->bg_color = COLOR_BACKGROUND;
    screen->on_show = NULL;
    screen->on_hide = NULL;
    screen->on_touch = NULL;
    screen->on_update = NULL;
    
    g_screens[g_screen_count++] = screen;
    
    printf("[UI] Screen created: %s\n", name);
    return screen;
}

/* Отображение экрана */
void ui_show_screen(Screen* screen) {
    if (g_current_screen && g_current_screen->on_hide) {
        g_current_screen->on_hide();
    }
    
    g_current_screen = screen;
    
    if (screen->on_show) {
        screen->on_show();
    }
    
    printf("[UI] Screen shown: %s\n", screen->name);
}

/* Скрытие экрана */
void ui_hide_screen(Screen* screen) {
    if (screen->on_hide) {
        screen->on_hide();
    }
    
    if (g_current_screen == screen) {
        g_current_screen = NULL;
    }
    
    printf("[UI] Screen hidden: %s\n", screen->name);
}

/* Добавление элемента на экран */
void ui_add_element(Screen* screen, UIElement* element) {
    if (screen->element_count < 64) {
        screen->elements[screen->element_count++] = element;
    }
}

/* Удаление элемента с экрана */
void ui_remove_element(Screen* screen, UIElement* element) {
    for (uint32_t i = 0; i < screen->element_count; i++) {
        if (screen->elements[i] == element) {
            for (uint32_t j = i; j < screen->element_count - 1; j++) {
                screen->elements[j] = screen->elements[j + 1];
            }
            screen->element_count--;
            free(element);
            return;
        }
    }
}

/* Обработка касания */
void ui_handle_touch(int x, int y) {
    if (!g_current_screen) return;
    
    for (uint32_t i = 0; i < g_current_screen->element_count; i++) {
        UIElement* elem = g_current_screen->elements[i];
        if (elem->visible && elem->enabled && ui_point_in_rect(x, y, elem->bounds)) {
            elem->focused = true;
            if (elem->on_click) {
                elem->on_click(elem);
            }
        }
    }
    
    if (g_current_screen->on_touch) {
        g_current_screen->on_touch(x, y);
    }
}

/* Обработка отпускания */
void ui_handle_release(int x, int y) {
    if (!g_current_screen) return;
    
    for (uint32_t i = 0; i < g_current_screen->element_count; i++) {
        g_current_screen->elements[i]->focused = false;
    }
}

/* Обработка движения */
void ui_handle_motion(int x, int y) {
    if (!g_current_screen) return;
}

/* Отрисовка элемента */
void ui_draw_element(UIElement* element) {
    if (!element->visible) return;
    
    switch (element->type) {
        case UI_BUTTON: {
            /* Рисование кнопки */
            Color bg = element->focused ? COLOR_ACCENT : element->bg_color;
            graphics_draw_rect(element->bounds, bg, true);
            graphics_draw_rect(element->bounds, COLOR_BORDER, false);
            
            int text_w = graphics_get_text_width(element->label);
            int text_h = graphics_get_text_height(element->label);
            int text_x = element->bounds.x + (element->bounds.w - text_w) / 2;
            int text_y = element->bounds.y + (element->bounds.h - text_h) / 2;
            graphics_draw_text(element->label, text_x, text_y, element->fg_color);
            break;
        }
        
        case UI_LABEL: {
            graphics_draw_text(element->label, element->bounds.x, element->bounds.y, element->fg_color);
            break;
        }
        
        case UI_ICON: {
            /* Рисование иконки как круга */
            graphics_draw_circle(
                element->bounds.x + element->bounds.w / 2,
                element->bounds.y + element->bounds.h / 2,
                element->bounds.w / 2,
                element->bg_color,
                true
            );
            graphics_draw_circle(
                element->bounds.x + element->bounds.w / 2,
                element->bounds.y + element->bounds.h / 2,
                element->bounds.w / 2,
                COLOR_BORDER,
                false
            );
            
            int text_w = graphics_get_text_width(element->label);
            int text_h = graphics_get_text_height(element->label);
            int text_x = element->bounds.x + (element->bounds.w - text_w) / 2;
            int text_y = element->bounds.y + (element->bounds.h - text_h) / 2;
            graphics_draw_text(element->label, text_x, text_y, COLOR_TEXT);
            break;
        }
        
        case UI_SLIDER: {
            graphics_draw_rect(element->bounds, element->bg_color, true);
            graphics_draw_rect(element->bounds, COLOR_BORDER, false);
            break;
        }
        
        case UI_TOGGLE: {
            graphics_draw_rect(element->bounds, element->bg_color, true);
            graphics_draw_rect(element->bounds, COLOR_BORDER, false);
            break;
        }
        
        case UI_PANEL: {
            graphics_draw_rect(element->bounds, element->bg_color, true);
            graphics_draw_rect(element->bounds, COLOR_BORDER, false);
            break;
        }
        
        default:
            break;
    }
    
    if (element->on_draw) {
        element->on_draw(element);
    }
}

/* Отрисовка экрана */
void ui_draw_screen(Screen* screen) {
    if (!screen) return;
    
    graphics_clear(screen->bg_color);
    
    for (uint32_t i = 0; i < screen->element_count; i++) {
        ui_draw_element(screen->elements[i]);
    }
}

/* Проверка нахождения точки в прямоугольнике */
bool ui_point_in_rect(int x, int y, Rect rect) {
    return x >= rect.x && x <= rect.x + rect.w &&
           y >= rect.y && y <= rect.y + rect.h;
}

/* Установка цветов элемента */
void ui_set_element_color(UIElement* elem, Color bg, Color fg) {
    elem->bg_color = bg;
    elem->fg_color = fg;
}

/* Установка метки элемента */
void ui_set_element_label(UIElement* elem, const char* label) {
    strncpy(elem->label, label, 255);
    elem->label[255] = '\0';
}
