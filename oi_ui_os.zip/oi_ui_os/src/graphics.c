#include "graphics.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>

/* Глобальные переменные */
static SDL_Window* g_window = NULL;
static SDL_Renderer* g_renderer = NULL;
static TTF_Font* g_font = NULL;
static int g_screen_width = 0;
static int g_screen_height = 0;

/* Инициализация графического сервера */
bool graphics_init(int width, int height, const char* title) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("[GRAPHICS] SDL initialization failed: %s\n", SDL_GetError());
        return false;
    }
    
    if (TTF_Init() < 0) {
        printf("[GRAPHICS] SDL_ttf initialization failed: %s\n", TTF_GetError());
        SDL_Quit();
        return false;
    }
    
    g_screen_width = width;
    g_screen_height = height;
    
    g_window = SDL_CreateWindow(
        title,
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        width, height,
        SDL_WINDOW_SHOWN | SDL_WINDOW_ALLOW_HIGHDPI
    );
    
    if (!g_window) {
        printf("[GRAPHICS] Window creation failed: %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return false;
    }
    
    g_renderer = SDL_CreateRenderer(
        g_window, -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
    );
    
    if (!g_renderer) {
        printf("[GRAPHICS] Renderer creation failed: %s\n", SDL_GetError());
        SDL_DestroyWindow(g_window);
        TTF_Quit();
        SDL_Quit();
        return false;
    }
    
    SDL_SetRenderDrawBlendMode(g_renderer, SDL_BLENDMODE_BLEND);
    
    printf("[GRAPHICS] Graphics server initialized: %dx%d\n", width, height);
    return true;
}

/* Завершение работы графического сервера */
void graphics_quit() {
    if (g_font) {
        TTF_CloseFont(g_font);
        g_font = NULL;
    }
    
    if (g_renderer) {
        SDL_DestroyRenderer(g_renderer);
        g_renderer = NULL;
    }
    
    if (g_window) {
        SDL_DestroyWindow(g_window);
        g_window = NULL;
    }
    
    TTF_Quit();
    SDL_Quit();
    
    printf("[GRAPHICS] Graphics server shutdown\n");
}

/* Очистка экрана */
void graphics_clear(Color color) {
    SDL_SetRenderDrawColor(g_renderer, color.r, color.g, color.b, color.a);
    SDL_RenderClear(g_renderer);
}

/* Обновление экрана */
void graphics_present() {
    SDL_RenderPresent(g_renderer);
}

/* Рисование прямоугольника */
void graphics_draw_rect(Rect rect, Color color, bool filled) {
    SDL_SetRenderDrawColor(g_renderer, color.r, color.g, color.b, color.a);
    SDL_Rect sdl_rect = {rect.x, rect.y, rect.w, rect.h};
    
    if (filled) {
        SDL_RenderFillRect(g_renderer, &sdl_rect);
    } else {
        SDL_RenderDrawRect(g_renderer, &sdl_rect);
    }
}

/* Рисование круга */
void graphics_draw_circle(int x, int y, int radius, Color color, bool filled) {
    SDL_SetRenderDrawColor(g_renderer, color.r, color.g, color.b, color.a);
    
    if (filled) {
        for (int w = 0; w < radius * 2; w++) {
            for (int h = 0; h < radius * 2; h++) {
                int dx = radius - w;
                int dy = radius - h;
                if ((dx*dx + dy*dy) <= (radius * radius)) {
                    SDL_RenderDrawPoint(g_renderer, x + dx, y + dy);
                }
            }
        }
    } else {
        int d = 3 - 2 * radius;
        int px = 0, py = radius;
        
        while (px <= py) {
            SDL_RenderDrawPoint(g_renderer, x + px, y + py);
            SDL_RenderDrawPoint(g_renderer, x - px, y + py);
            SDL_RenderDrawPoint(g_renderer, x + px, y - py);
            SDL_RenderDrawPoint(g_renderer, x - px, y - py);
            SDL_RenderDrawPoint(g_renderer, x + py, y + px);
            SDL_RenderDrawPoint(g_renderer, x - py, y + px);
            SDL_RenderDrawPoint(g_renderer, x + py, y - px);
            SDL_RenderDrawPoint(g_renderer, x - py, y - px);
            
            if (d < 0) {
                d = d + 4 * px + 6;
            } else {
                d = d + 4 * (px - py) + 10;
                py--;
            }
            px++;
        }
    }
}

/* Рисование линии */
void graphics_draw_line(int x1, int y1, int x2, int y2, Color color, int thickness) {
    SDL_SetRenderDrawColor(g_renderer, color.r, color.g, color.b, color.a);
    
    for (int i = 0; i < thickness; i++) {
        SDL_RenderDrawLine(g_renderer, x1, y1 + i, x2, y2 + i);
    }
}

/* Рисование треугольника */
void graphics_draw_triangle(Point p1, Point p2, Point p3, Color color, bool filled) {
    SDL_SetRenderDrawColor(g_renderer, color.r, color.g, color.b, color.a);
    
    if (filled) {
        /* Простая заливка треугольника */
        graphics_draw_line(p1.x, p1.y, p2.x, p2.y, color, 1);
        graphics_draw_line(p2.x, p2.y, p3.x, p3.y, color, 1);
        graphics_draw_line(p3.x, p3.y, p1.x, p1.y, color, 1);
    } else {
        graphics_draw_line(p1.x, p1.y, p2.x, p2.y, color, 1);
        graphics_draw_line(p2.x, p2.y, p3.x, p3.y, color, 1);
        graphics_draw_line(p3.x, p3.y, p1.x, p1.y, color, 1);
    }
}

/* Загрузка шрифта */
bool graphics_load_font(const char* path, int size) {
    if (g_font) {
        TTF_CloseFont(g_font);
    }
    
    g_font = TTF_OpenFont(path, size);
    if (!g_font) {
        printf("[GRAPHICS] Font loading failed: %s\n", TTF_GetError());
        return false;
    }
    
    printf("[GRAPHICS] Font loaded: %s (%d pt)\n", path, size);
    return true;
}

/* Рисование текста */
void graphics_draw_text(const char* text, int x, int y, Color color) {
    if (!g_font) return;
    
    SDL_Color sdl_color = {color.r, color.g, color.b, color.a};
    SDL_Surface* surface = TTF_RenderText_Blended(g_font, text, sdl_color);
    
    if (!surface) return;
    
    SDL_Texture* texture = SDL_CreateTextureFromSurface(g_renderer, surface);
    if (texture) {
        SDL_Rect dest = {x, y, surface->w, surface->h};
        SDL_RenderCopy(g_renderer, texture, NULL, &dest);
        SDL_DestroyTexture(texture);
    }
    
    SDL_FreeSurface(surface);
}

/* Получение ширины текста */
int graphics_get_text_width(const char* text) {
    if (!g_font) return 0;
    
    int w = 0;
    TTF_SizeText(g_font, text, &w, NULL);
    return w;
}

/* Получение высоты текста */
int graphics_get_text_height(const char* text) {
    if (!g_font) return 0;
    
    int h = 0;
    TTF_SizeText(g_font, text, NULL, &h);
    return h;
}

/* Загрузка изображения */
Texture graphics_load_image(const char* path) {
    SDL_Surface* surface = IMG_Load(path);
    if (!surface) {
        printf("[GRAPHICS] Image loading failed: %s\n", IMG_GetError());
        return NULL;
    }
    
    SDL_Texture* texture = SDL_CreateTextureFromSurface(g_renderer, surface);
    SDL_FreeSurface(surface);
    
    return (Texture)texture;
}

/* Отрисовка текстуры */
void graphics_draw_texture(Texture tex, Rect dest) {
    if (!tex) return;
    
    SDL_Rect sdl_dest = {dest.x, dest.y, dest.w, dest.h};
    SDL_RenderCopy(g_renderer, (SDL_Texture*)tex, NULL, &sdl_dest);
}

/* Освобождение текстуры */
void graphics_free_texture(Texture tex) {
    if (tex) {
        SDL_DestroyTexture((SDL_Texture*)tex);
    }
}

/* Получение ширины экрана */
int graphics_get_width() {
    return g_screen_width;
}

/* Получение высоты экрана */
int graphics_get_height() {
    return g_screen_height;
}

/* Получение SDL рендерера */
SDL_Renderer* graphics_get_renderer() {
    return g_renderer;
}
