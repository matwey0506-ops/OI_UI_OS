#include "ui.h"
#include "graphics.h"
#include "kernel.h"
#include <stdio.h>
#include <time.h>

/* Структура приложения */
typedef struct {
    const char* name;
    const char* icon;
    uint32_t pid;
} App;

/* Доступные приложения */
static App apps[] = {
    {"Camera", "📷", 0},
    {"Gallery", "🖼️", 0},
    {"Messages", "💬", 0},
    {"Phone", "☎️", 0},
    {"Settings", "⚙️", 0},
    {"Browser", "🌐", 0},
    {"Music", "🎵", 0},
    {"Files", "📁", 0}
};

static int apps_count = 8;

/* Обработчик клика на приложение */
void app_button_clicked(UIElement* elem) {
    const char* app_name = elem->label;
    printf("[HOME] App launched: %s\n", app_name);
    
    /* Запуск процесса приложения */
    uint32_t pid = kernel_create_process(app_name);
    
    /* Поиск и обновление PID приложения */
    for (int i = 0; i < apps_count; i++) {
        if (strcmp(apps[i].name, app_name) == 0) {
            apps[i].pid = pid;
            break;
        }
    }
}

/* Обработчик экрана загрузки */
void home_screen_on_show() {
    printf("[HOME] Home screen shown\n");
}

void home_screen_on_hide() {
    printf("[HOME] Home screen hidden\n");
}

void home_screen_on_touch(int x, int y) {
    printf("[HOME] Touch at: %d, %d\n", x, y);
}

void home_screen_on_update() {
    /* Обновление системной информации */
    kernel_update_system_info();
}

/* Отрисовка статус-бара */
void home_screen_draw_statusbar(int width) {
    SystemInfo* sys_info = kernel_get_system_info();
    DeviceInfo* dev_info = kernel_get_device_info();
    
    /* Фон статус-бара */
    Rect statusbar = {0, 0, width, 50};
    graphics_draw_rect(statusbar, COLOR_PRIMARY, true);
    
    /* Время */
    time_t now = time(NULL);
    struct tm* timeinfo = localtime(&now);
    char time_str[16];
    strftime(time_str, sizeof(time_str), "%H:%M", timeinfo);
    graphics_draw_text(time_str, 20, 15, COLOR_WHITE);
    
    /* Батарея */
    char battery_str[32];
    snprintf(battery_str, sizeof(battery_str), "🔋 %.0f%%", sys_info->battery_level);
    int battery_x = width - graphics_get_text_width(battery_str) - 20;
    graphics_draw_text(battery_str, battery_x, 15, COLOR_WHITE);
    
    /* Wi-Fi */
    if (dev_info->wifi_enabled) {
        graphics_draw_text("📶", width - 120, 15, COLOR_WHITE);
    }
    
    /* Сигнал */
    graphics_draw_text("📡", width - 100, 15, COLOR_WHITE);
}

/* Отрисовка главного экрана */
void home_screen_draw() {
    int width = graphics_get_width();
    int height = graphics_get_height();
    
    /* Фон */
    graphics_clear(COLOR_BACKGROUND);
    
    /* Статус-бар */
    home_screen_draw_statusbar(width);
    
    /* Сетка приложений */
    int cols = 4;
    int rows = 2;
    int app_size = 100;
    int spacing = 20;
    int start_x = (width - (cols * (app_size + spacing))) / 2;
    int start_y = 100;
    
    for (int i = 0; i < apps_count; i++) {
        int col = i % cols;
        int row = i / cols;
        
        int x = start_x + col * (app_size + spacing);
        int y = start_y + row * (app_size + spacing);
        
        /* Иконка приложения */
        graphics_draw_circle(x + app_size / 2, y + app_size / 2, app_size / 2, COLOR_WHITE, true);
        graphics_draw_circle(x + app_size / 2, y + app_size / 2, app_size / 2, COLOR_BORDER, false);
        
        /* Иконка (эмодзи) */
        graphics_draw_text(apps[i].icon, x + app_size / 2 - 15, y + app_size / 2 - 20, COLOR_TEXT);
        
        /* Название приложения */
        int text_w = graphics_get_text_width(apps[i].name);
        graphics_draw_text(apps[i].name, x + (app_size - text_w) / 2, y + app_size + 10, COLOR_TEXT);
    }
    
    /* Информация о системе внизу */
    SystemInfo* sys_info = kernel_get_system_info();
    char sys_info_str[128];
    snprintf(sys_info_str, sizeof(sys_info_str), 
             "Uptime: %us | CPU: %u%% | Processes: %u",
             sys_info->uptime_seconds, sys_info->cpu_usage, 8);
    
    graphics_draw_text(sys_info_str, 20, height - 30, COLOR_TEXT);
}

/* Создание главного экрана */
Screen* home_screen_create() {
    Screen* screen = ui_create_screen("Home Screen");
    screen->bg_color = COLOR_BACKGROUND;
    screen->on_show = home_screen_on_show;
    screen->on_hide = home_screen_on_hide;
    screen->on_touch = home_screen_on_touch;
    screen->on_update = home_screen_on_update;
    
    printf("[HOME] Home screen created\n");
    
    return screen;
}

/* Получение функции отрисовки */
void (*home_screen_get_draw_func())() {
    return home_screen_draw;
}
