# OI UI OS - Архитектура системы

## Обзор

OI UI OS — это многоуровневая операционная система для сенсорных устройств, построенная на C с использованием SDL2 для графики.

```
┌─────────────────────────────────────────────────────┐
│              Application Layer                      │
│  ┌──────────────┬──────────────┬──────────────────┐ │
│  │ Boot Screen  │ Home Screen  │ Settings Screen  │ │
│  └──────────────┴──────────────┴──────────────────┘ │
├─────────────────────────────────────────────────────┤
│              UI Framework Layer                     │
│  ┌──────────────┬──────────────┬──────────────────┐ │
│  │ UI Elements  │ Screen Mgmt  │ Event Handling   │ │
│  └──────────────┴──────────────┴──────────────────┘ │
├─────────────────────────────────────────────────────┤
│              Graphics Layer                         │
│  ┌──────────────┬──────────────┬──────────────────┐ │
│  │ Primitives   │ Text Render  │ Texture Mgmt     │ │
│  └──────────────┴──────────────┴──────────────────┘ │
├─────────────────────────────────────────────────────┤
│              Kernel Layer                           │
│  ┌──────────────┬──────────────┬──────────────────┐ │
│  │ Process Mgmt │ Memory Mgmt  │ Device Info      │ │
│  └──────────────┴──────────────┴──────────────────┘ │
├─────────────────────────────────────────────────────┤
│              SDL2 / System Libraries                │
└─────────────────────────────────────────────────────┘
```

## Слои архитектуры

### 1. Kernel Layer (kernel.c, kernel.h)

**Ответственность:**
- Управление процессами
- Управление памятью
- Информация о системе
- Управление устройством

**Основные структуры:**
```c
typedef struct {
    char os_name[64];
    char os_version[32];
    uint32_t uptime_seconds;
    uint32_t total_memory;
    uint32_t free_memory;
    uint32_t cpu_usage;
    float battery_level;
    bool charging;
    float temperature;
} SystemInfo;

typedef struct {
    uint16_t screen_width;
    uint16_t screen_height;
    uint16_t screen_dpi;
    bool touchscreen;
    bool accelerometer;
    bool gyroscope;
    float brightness;
    bool wifi_enabled;
    bool bluetooth_enabled;
    bool airplane_mode;
} DeviceInfo;

typedef struct {
    uint32_t pid;
    char name[64];
    uint32_t memory_usage;
    uint8_t priority;
    uint8_t state;
} Process;
```

**Основные функции:**
- `kernel_init()` - инициализация ядра
- `kernel_create_process()` - создание процесса
- `kernel_kill_process()` - завершение процесса
- `kernel_get_system_info()` - получение информации о системе
- `kernel_get_device_info()` - получение информации об устройстве

### 2. Graphics Layer (graphics.c, graphics.h)

**Ответственность:**
- Инициализация SDL2
- Рисование примитивов
- Работа с текстом
- Работа с текстурами

**Основные структуры:**
```c
typedef struct {
    uint8_t r, g, b, a;
} Color;

typedef struct {
    int x, y, w, h;
} Rect;

typedef struct {
    int x, y;
} Point;
```

**Основные функции:**
- `graphics_init()` - инициализация графики
- `graphics_clear()` - очистка экрана
- `graphics_draw_rect()` - рисование прямоугольника
- `graphics_draw_circle()` - рисование круга
- `graphics_draw_text()` - рисование текста
- `graphics_present()` - обновление экрана

**Цветовая палитра:**
```c
#define COLOR_PRIMARY    color_make(33, 150, 243, 255)   // Синий
#define COLOR_SECONDARY  color_make(76, 175, 80, 255)    // Зелёный
#define COLOR_ACCENT     color_make(255, 152, 0, 255)    // Оранжевый
#define COLOR_BACKGROUND color_make(245, 245, 245, 255)  // Светло-серый
#define COLOR_TEXT       color_make(33, 33, 33, 255)     // Тёмно-серый
#define COLOR_BORDER     color_make(224, 224, 224, 255)  // Серый
```

### 3. UI Framework Layer (ui.c, ui.h)

**Ответственность:**
- Создание UI элементов
- Управление экранами
- Обработка событий
- Отрисовка интерфейса

**Основные структуры:**
```c
typedef struct UIElement {
    UIElementType type;
    Rect bounds;
    Color bg_color;
    Color fg_color;
    bool visible;
    bool enabled;
    bool focused;
    char label[256];
    void (*on_click)(struct UIElement* self);
    void (*on_draw)(struct UIElement* self);
    void* data;
} UIElement;

typedef struct {
    char name[64];
    UIElement** elements;
    uint32_t element_count;
    Color bg_color;
    void (*on_show)();
    void (*on_hide)();
    void (*on_touch)(int x, int y);
    void (*on_update)();
} Screen;
```

**Типы элементов:**
- `UI_BUTTON` - кнопка
- `UI_LABEL` - метка
- `UI_ICON` - иконка
- `UI_SLIDER` - слайдер
- `UI_TOGGLE` - переключатель
- `UI_TEXTBOX` - текстовое поле
- `UI_PANEL` - панель
- `UI_GRID` - сетка

**Основные функции:**
- `ui_create_screen()` - создание экрана
- `ui_create_button()` - создание кнопки
- `ui_create_label()` - создание метки
- `ui_add_element()` - добавление элемента
- `ui_show_screen()` - показ экрана
- `ui_handle_touch()` - обработка касания
- `ui_draw_screen()` - отрисовка экрана

### 4. Application Layer

**Ответственность:**
- Реализация приложений
- Использование UI Framework
- Взаимодействие с ядром

**Приложения:**

#### Boot Screen (boot_screen.c)
- Экран загрузки с логотипом
- Прогресс-бар
- Этапы загрузки (7 этапов)
- Длительность: ~8 секунд

#### Home Screen (home_screen.c)
- Главный экран с приложениями
- Сетка 4x2 (8 приложений)
- Статус-бар с временем и батареей
- Информация о системе внизу

#### Settings Screen (settings_screen.c)
- Меню настроек
- 8 пунктов меню
- Управление яркостью, звуком
- Информация о батарее и памяти

## Поток выполнения

### Инициализация

```
main()
  ├─ kernel_init()
  │  ├─ Инициализация системной информации
  │  ├─ Инициализация информации об устройстве
  │  └─ Инициализация управления процессами
  ├─ graphics_init()
  │  ├─ SDL_Init()
  │  ├─ SDL_CreateWindow()
  │  ├─ SDL_CreateRenderer()
  │  └─ graphics_load_font()
  ├─ ui_init()
  │  └─ Инициализация UI системы
  ├─ boot_screen_create()
  ├─ home_screen_create()
  ├─ settings_screen_create()
  └─ ui_show_screen(boot_screen)
```

### Главный цикл

```
while (running) {
  ├─ handle_events()
  │  ├─ SDL_PollEvent()
  │  ├─ Обработка касания
  │  ├─ Обработка мыши
  │  └─ Обработка клавиатуры
  ├─ update()
  │  ├─ boot_screen_on_update()
  │  └─ screen->on_update()
  ├─ render()
  │  ├─ graphics_clear()
  │  ├─ ui_draw_screen()
  │  └─ graphics_present()
  └─ SDL_Delay(16) // ~60 FPS
}
```

### Обработка события касания

```
SDL_FINGERDOWN
  ├─ Преобразование координат
  ├─ ui_handle_touch(x, y)
  │  ├─ Проверка попадания в элементы
  │  ├─ Установка focused = true
  │  ├─ Вызов on_click()
  │  └─ Вызов screen->on_touch()
  └─ Обновление UI
```

## Управление памятью

### Выделение памяти

```c
// Через kernel API
void* ptr = kernel_malloc(size);

// Или напрямую
void* ptr = malloc(size);
```

### Освобождение памяти

```c
// Через kernel API
kernel_free(ptr);

// Или напрямую
free(ptr);
```

### Утечки памяти

Проверка утечек:
```bash
valgrind --leak-check=full ./build/oi_ui_os
```

## Обработка событий

### Типы событий

1. **Касание** (SDL_FINGERDOWN, SDL_FINGERUP)
   - Преобразование координат
   - Проверка попадания в элементы
   - Вызов обработчиков

2. **Мышь** (SDL_MOUSEBUTTONDOWN, SDL_MOUSEBUTTONUP)
   - Аналогично касанию
   - Для тестирования на ПК

3. **Клавиатура** (SDL_KEYDOWN)
   - ESC для выхода
   - Другие клавиши для навигации

4. **Выход** (SDL_QUIT)
   - Завершение главного цикла
   - Очистка ресурсов

## Оптимизация

### Производительность

1. **Отрисовка**
   - Использование double buffering
   - Минимизация перерисовок
   - Оптимизация примитивов

2. **Обработка событий**
   - Кэширование результатов
   - Минимизация вычислений

3. **Память**
   - Переиспользование объектов
   - Избегание фрагментации

### Профилирование

```bash
# Использование valgrind
valgrind --tool=callgrind ./build/oi_ui_os

# Использование gprof
gcc -pg -o oi_ui_os *.c
./oi_ui_os
gprof oi_ui_os gmon.out
```

## Расширяемость

### Добавление нового экрана

1. Создать файл `src/new_screen.c`
2. Реализовать функции `on_show`, `on_hide`, `on_touch`, `on_update`
3. Создать функцию `new_screen_create()`
4. Добавить в `main.c`
5. Обновить `CMakeLists.txt`

### Добавление нового компонента

1. Создать структуру в `include/components.h`
2. Реализовать функции в `src/components.c`
3. Добавить в `CMakeLists.txt`
4. Использовать в приложениях

### Добавление нового UI элемента

1. Добавить тип в `UIElementType` enum
2. Реализовать создание в `ui_create_*()`
3. Реализовать отрисовку в `ui_draw_element()`
4. Реализовать обработку событий

## Безопасность

### Проверки

- Проверка NULL указателей
- Проверка границ массивов
- Проверка переполнения буфера
- Проверка ошибок функций

### Примеры

```c
// Проверка NULL
if (!ptr) {
    printf("[ERROR] Null pointer\n");
    return;
}

// Проверка границ
if (index >= array_size) {
    printf("[ERROR] Index out of bounds\n");
    return;
}

// Проверка ошибок
if (!graphics_init(width, height, title)) {
    printf("[ERROR] Graphics initialization failed\n");
    return 1;
}
```

## Тестирование

### Модульное тестирование

```bash
gcc -o test_kernel test_kernel.c src/kernel.c -I./include
./test_kernel
```

### Интеграционное тестирование

```bash
./build/oi_ui_os
# Проверить все экраны и функции вручную
```

### Нагрузочное тестирование

```bash
# Запустить с профилировщиком
valgrind --tool=massif ./build/oi_ui_os
```

---

**Версия**: 1.0  
**Дата**: 2026-06-01
