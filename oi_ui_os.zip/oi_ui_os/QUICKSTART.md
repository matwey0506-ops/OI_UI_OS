# OI UI OS - Быстрый старт

## Установка (Ubuntu/Debian)

```bash
# 1. Установка зависимостей
sudo apt-get update
sudo apt-get install -y libsdl2-dev libsdl2-ttf-dev libsdl2-image-dev cmake build-essential

# 2. Клонирование/переход в директорию проекта
cd /home/ubuntu/oi_ui_os

# 3. Создание директории сборки
mkdir -p build
cd build

# 4. Конфигурация и сборка
cmake ..
make -j4

# 5. Запуск ОС
./oi_ui_os
```

## Установка (macOS)

```bash
# 1. Установка зависимостей через Homebrew
brew install sdl2 sdl2_ttf sdl2_image cmake

# 2. Остальные шаги как на Ubuntu
cd /home/ubuntu/oi_ui_os
mkdir -p build && cd build
cmake ..
make -j4
./oi_ui_os
```

## Установка (Fedora/RHEL)

```bash
# 1. Установка зависимостей
sudo dnf install SDL2-devel SDL2_ttf-devel SDL2_image-devel cmake gcc

# 2. Остальные шаги как на Ubuntu
cd /home/ubuntu/oi_ui_os
mkdir -p build && cd build
cmake ..
make -j4
./oi_ui_os
```

## Использование

### Главный экран
- **Сетка приложений**: 8 приложений с иконками
- **Статус-бар**: Время, батарея, сигнал
- **Информация о системе**: Внизу экрана

### Экран загрузки
- Автоматически показывается при запуске
- Длится ~8 секунд
- Показывает прогресс загрузки

### Управление
- **Левая кнопка мыши / Сенсор**: Нажимайте на элементы
- **ESC**: Выход

## Структура файлов

```
oi_ui_os/
├── include/              # Заголовочные файлы
│   ├── kernel.h         # Ядро ОС
│   ├── graphics.h       # Графический сервер
│   ├── ui.h             # UI фреймворк
│   └── components.h     # Компоненты
├── src/                 # Исходные файлы
│   ├── main.c           # Главная программа
│   ├── kernel.c         # Реализация ядра
│   ├── graphics.c       # Реализация графики
│   ├── ui.c             # Реализация UI
│   ├── boot_screen.c    # Экран загрузки
│   ├── home_screen.c    # Главный экран
│   ├── settings_screen.c # Экран настроек
│   └── components.c     # Компоненты
├── build/               # Директория сборки
├── CMakeLists.txt       # Конфигурация CMake
├── README.md            # Полная документация
├── DEVELOPMENT.md       # Руководство разработчика
├── EXAMPLES.md          # Примеры кода
└── QUICKSTART.md        # Этот файл
```

## Основные компоненты

### Kernel (kernel.c)
- Управление процессами
- Управление памятью
- Системная информация
- Информация об устройстве

### Graphics (graphics.c)
- Инициализация SDL2
- Рисование примитивов
- Работа с текстом
- Работа с изображениями

### UI Framework (ui.c)
- Создание UI элементов
- Управление экранами
- Обработка событий
- Отрисовка интерфейса

### Boot Screen (boot_screen.c)
- Экран загрузки с логотипом
- Прогресс-бар
- Этапы загрузки

### Home Screen (home_screen.c)
- Главный экран с приложениями
- Статус-бар
- Информация о системе

### Settings (settings_screen.c)
- Меню настроек
- Управление устройством
- Информация о системе

## Команды сборки

### Обычная сборка
```bash
cd build
cmake ..
make -j4
```

### Отладочная сборка
```bash
cd build
cmake -DCMAKE_BUILD_TYPE=Debug ..
make -j4
gdb ./oi_ui_os
```

### Оптимизированная сборка
```bash
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j4 -s
```

### Очистка
```bash
cd build
make clean
rm -rf *
```

## Решение проблем

### Ошибка: "SDL2 not found"
```bash
# Ubuntu/Debian
sudo apt-get install libsdl2-dev

# macOS
brew install sdl2

# Fedora
sudo dnf install SDL2-devel
```

### Ошибка: "cmake not found"
```bash
# Ubuntu/Debian
sudo apt-get install cmake

# macOS
brew install cmake

# Fedora
sudo dnf install cmake
```

### Ошибка: "gcc not found"
```bash
# Ubuntu/Debian
sudo apt-get install build-essential

# macOS
xcode-select --install

# Fedora
sudo dnf install gcc
```

### Приложение не запускается
1. Проверьте, что все зависимости установлены
2. Пересоберите проект: `make clean && make -j4`
3. Проверьте логи в консоли

## Примеры использования

### Создание простого приложения
```c
Screen* screen = ui_create_screen("My App");
UIElement* btn = ui_create_button(100, 100, 200, 50, "Click");
ui_add_element(screen, btn);
ui_show_screen(screen);
```

### Работа с системной информацией
```c
SystemInfo* sys = kernel_get_system_info();
printf("Battery: %.1f%%\n", sys->battery_level);
```

### Рисование графики
```c
graphics_clear(COLOR_WHITE);
graphics_draw_rect({100, 100, 200, 150}, COLOR_PRIMARY, true);
graphics_draw_text("Hello", 150, 150, COLOR_TEXT);
graphics_present();
```

Подробные примеры см. в файле `EXAMPLES.md`

## Дополнительные ресурсы

- **README.md** - Полная документация
- **DEVELOPMENT.md** - Руководство разработчика
- **EXAMPLES.md** - Примеры кода
- **SDL2 Wiki** - https://wiki.libsdl.org/

## Поддержка

Для вопросов и проблем:
1. Проверьте документацию
2. Посмотрите примеры в `EXAMPLES.md`
3. Прочитайте `DEVELOPMENT.md`

---

**Версия**: 1.0  
**Последнее обновление**: 2026-06-01
