#ifndef UI_H
#define UI_H

#include <stdint.h>
#include <stdbool.h>
#include "graphics.h"

/* Типы элементов UI */
typedef enum {
    UI_BUTTON,
    UI_LABEL,
    UI_ICON,
    UI_SLIDER,
    UI_TOGGLE,
    UI_TEXTBOX,
    UI_PANEL,
    UI_GRID
} UIElementType;

/* Структура элемента UI */
typedef struct UIElement {
    UIElementType type;
    Rect bounds;
    Color bg_color;
    Color fg_color;
    bool visible;
    bool enabled;
    bool focused;
    char label[256];
    void (*on_click)(struct UIElement* self);
    void (*on_draw)(struct UIElement* self);
    void* data;
} UIElement;

/* Структура экрана */
typedef struct {
    char name[64];
    UIElement** elements;
    uint32_t element_count;
    Color bg_color;
    void (*on_show)();
    void (*on_hide)();
    void (*on_touch)(int x, int y);
    void (*on_update)();
} Screen;

/* Инициализация UI системы */
void ui_init();

/* Создание элементов */
UIElement* ui_create_button(int x, int y, int w, int h, const char* label);
UIElement* ui_create_label(int x, int y, const char* text);
UIElement* ui_create_icon(int x, int y, int size, const char* icon_name);
UIElement* ui_create_slider(int x, int y, int w, int min_val, int max_val);
UIElement* ui_create_toggle(int x, int y, bool initial_state);
UIElement* ui_create_panel(int x, int y, int w, int h);

/* Работа с экранами */
Screen* ui_create_screen(const char* name);
void ui_show_screen(Screen* screen);
void ui_hide_screen(Screen* screen);
void ui_add_element(Screen* screen, UIElement* element);
void ui_remove_element(Screen* screen, UIElement* element);

/* Обработка событий */
void ui_handle_touch(int x, int y);
void ui_handle_release(int x, int y);
void ui_handle_motion(int x, int y);

/* Отрисовка */
void ui_draw_screen(Screen* screen);
void ui_draw_element(UIElement* element);

/* Утилиты */
bool ui_point_in_rect(int x, int y, Rect rect);
void ui_set_element_color(UIElement* elem, Color bg, Color fg);
void ui_set_element_label(UIElement* elem, const char* label);

#endif /* UI_H */
