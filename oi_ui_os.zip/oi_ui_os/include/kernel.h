#ifndef KERNEL_H
#define KERNEL_H

#include <stdint.h>
#include <stdbool.h>
#include <time.h>

/* Версия ОС */
#define OS_VERSION "OI UI v1.0"
#define OS_NAME "OI UI Operating System"

/* Структура информации о системе */
typedef struct {
    char os_name[64];
    char os_version[32];
    uint32_t uptime_seconds;
    uint32_t total_memory;
    uint32_t free_memory;
    uint32_t cpu_usage;
    float battery_level;
    bool charging;
    float temperature;
} SystemInfo;

/* Структура устройства */
typedef struct {
    uint16_t screen_width;
    uint16_t screen_height;
    uint16_t screen_dpi;
    bool touchscreen;
    bool accelerometer;
    bool gyroscope;
    float brightness;
    bool wifi_enabled;
    bool bluetooth_enabled;
    bool airplane_mode;
} DeviceInfo;

/* Структура процесса */
typedef struct {
    uint32_t pid;
    char name[64];
    uint32_t memory_usage;
    uint8_t priority;
    uint8_t state; /* 0=stopped, 1=running, 2=paused */
} Process;

/* Инициализация ядра */
void kernel_init();

/* Получение информации о системе */
SystemInfo* kernel_get_system_info();

/* Получение информации об устройстве */
DeviceInfo* kernel_get_device_info();

/* Обновление системной информации */
void kernel_update_system_info();

/* Управление процессами */
uint32_t kernel_create_process(const char* name);
void kernel_kill_process(uint32_t pid);
void kernel_pause_process(uint32_t pid);
void kernel_resume_process(uint32_t pid);

/* Управление памятью */
void* kernel_malloc(size_t size);
void kernel_free(void* ptr);

/* Управление питанием */
void kernel_set_brightness(float level);
void kernel_sleep();
void kernel_wake();

#endif /* KERNEL_H */
