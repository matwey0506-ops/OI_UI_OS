#ifndef COMPONENTS_H
#define COMPONENTS_H

#include "ui.h"
#include "graphics.h"

/* Компонент: Статус-бар */
typedef struct {
    int height;
    Color bg_color;
    bool show_time;
    bool show_battery;
    bool show_signal;
} StatusBar;

StatusBar* statusbar_create(int height);
void statusbar_draw(StatusBar* bar, int width);
void statusbar_update(StatusBar* bar);
void statusbar_free(StatusBar* bar);

/* Компонент: Навигационное меню */
typedef struct {
    const char** items;
    int item_count;
    int selected_index;
    int height;
    Color bg_color;
    Color fg_color;
} NavigationBar;

NavigationBar* navbar_create(const char** items, int count, int height);
void navbar_draw(NavigationBar* bar, int width);
void navbar_handle_click(NavigationBar* bar, int x, int y);
void navbar_free(NavigationBar* bar);

/* Компонент: Диалоговое окно */
typedef struct {
    const char* title;
    const char* message;
    const char* ok_text;
    const char* cancel_text;
    bool visible;
    void (*on_ok)();
    void (*on_cancel)();
} Dialog;

Dialog* dialog_create(const char* title, const char* message);
void dialog_show(Dialog* dialog);
void dialog_hide(Dialog* dialog);
void dialog_draw(Dialog* dialog, int width, int height);
void dialog_free(Dialog* dialog);

/* Компонент: Уведомление */
typedef struct {
    const char* message;
    int duration;
    int elapsed;
    Color bg_color;
    bool visible;
} Notification;

Notification* notification_create(const char* message, int duration);
void notification_show(Notification* notif);
void notification_update(Notification* notif);
void notification_draw(Notification* notif, int width, int height);
void notification_free(Notification* notif);

/* Компонент: Прогресс-бар */
typedef struct {
    int x, y, w, h;
    int value;
    int max_value;
    Color bg_color;
    Color fill_color;
} ProgressBar;

ProgressBar* progressbar_create(int x, int y, int w, int h, int max_value);
void progressbar_set_value(ProgressBar* pb, int value);
void progressbar_draw(ProgressBar* pb);
void progressbar_free(ProgressBar* pb);

#endif /* COMPONENTS_H */
