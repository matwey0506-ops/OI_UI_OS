#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <stdint.h>
#include <stdbool.h>
#include <SDL2/SDL.h>

/* Цветовые схемы */
typedef struct {
    uint8_t r, g, b, a;
} Color;

/* Функции для создания цветов */
static inline Color color_make(uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    return (Color){r, g, b, a};
}

/* Предопределённые цвета */
#define COLOR_BLACK color_make(0, 0, 0, 255)
#define COLOR_WHITE color_make(255, 255, 255, 255)
#define COLOR_PRIMARY color_make(33, 150, 243, 255)
#define COLOR_SECONDARY color_make(76, 175, 80, 255)
#define COLOR_ACCENT color_make(255, 152, 0, 255)
#define COLOR_BACKGROUND color_make(245, 245, 245, 255)
#define COLOR_TEXT color_make(33, 33, 33, 255)
#define COLOR_BORDER color_make(224, 224, 224, 255)

/* Структура прямоугольника */
typedef struct {
    int x, y, w, h;
} Rect;

/* Структура точки */
typedef struct {
    int x, y;
} Point;

/* Инициализация графического сервера */
bool graphics_init(int width, int height, const char* title);

/* Завершение работы графического сервера */
void graphics_quit();

/* Очистка экрана */
void graphics_clear(Color color);

/* Обновление экрана */
void graphics_present();

/* Рисование примитивов */
void graphics_draw_rect(Rect rect, Color color, bool filled);
void graphics_draw_circle(int x, int y, int radius, Color color, bool filled);
void graphics_draw_line(int x1, int y1, int x2, int y2, Color color, int thickness);
void graphics_draw_triangle(Point p1, Point p2, Point p3, Color color, bool filled);

/* Работа с текстом */
bool graphics_load_font(const char* path, int size);
void graphics_draw_text(const char* text, int x, int y, Color color);
int graphics_get_text_width(const char* text);
int graphics_get_text_height(const char* text);

/* Работа с текстурами/изображениями */
typedef void* Texture;
Texture graphics_load_image(const char* path);
void graphics_draw_texture(Texture tex, Rect dest);
void graphics_free_texture(Texture tex);

/* Получение размеров окна */
int graphics_get_width();
int graphics_get_height();

/* Получение SDL рендерера */
SDL_Renderer* graphics_get_renderer();

#endif /* GRAPHICS_H */
