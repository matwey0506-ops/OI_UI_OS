# OI UI OS - Примеры использования

## Пример 1: Создание простого приложения

```c
#include "kernel.h"
#include "graphics.h"
#include "ui.h"

/* Обработчик клика кнопки */
void my_button_clicked(UIElement* elem) {
    printf("Button clicked: %s\n", elem->label);
    uint32_t pid = kernel_create_process("MyApp");
}

/* Создание экрана приложения */
Screen* create_my_app_screen() {
    Screen* screen = ui_create_screen("My App");
    
    /* Создание кнопки */
    UIElement* btn = ui_create_button(100, 100, 200, 50, "Click Me");
    btn->on_click = my_button_clicked;
    ui_add_element(screen, btn);
    
    /* Создание метки */
    UIElement* lbl = ui_create_label(100, 200, "Hello, OI UI!");
    ui_add_element(screen, lbl);
    
    return screen;
}
```

## Пример 2: Работа с системной информацией

```c
#include "kernel.h"
#include <stdio.h>

int main() {
    kernel_init();
    
    SystemInfo* sys_info = kernel_get_system_info();
    DeviceInfo* dev_info = kernel_get_device_info();
    
    printf("OS: %s\n", sys_info->os_name);
    printf("Version: %s\n", sys_info->os_version);
    printf("Uptime: %u seconds\n", sys_info->uptime_seconds);
    printf("Battery: %.1f%%\n", sys_info->battery_level);
    
    printf("Screen: %dx%d\n", dev_info->screen_width, dev_info->screen_height);
    printf("DPI: %d\n", dev_info->screen_dpi);
    printf("Touchscreen: %s\n", dev_info->touchscreen ? "Yes" : "No");
    
    return 0;
}
```

## Пример 3: Управление процессами

```c
#include "kernel.h"
#include <stdio.h>

int main() {
    kernel_init();
    
    /* Создание процессов */
    uint32_t pid1 = kernel_create_process("App1");
    uint32_t pid2 = kernel_create_process("App2");
    uint32_t pid3 = kernel_create_process("App3");
    
    printf("Created processes: %u, %u, %u\n", pid1, pid2, pid3);
    
    /* Пауза процесса */
    kernel_pause_process(pid1);
    printf("Paused process: %u\n", pid1);
    
    /* Возобновление процесса */
    kernel_resume_process(pid1);
    printf("Resumed process: %u\n", pid1);
    
    /* Завершение процесса */
    kernel_kill_process(pid2);
    printf("Killed process: %u\n", pid2);
    
    return 0;
}
```

## Пример 4: Рисование графики

```c
#include "graphics.h"

int main() {
    if (!graphics_init(800, 600, "Graphics Demo")) {
        return 1;
    }
    
    graphics_load_font("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 24);
    
    bool running = true;
    while (running) {
        /* Очистка экрана */
        graphics_clear(COLOR_WHITE);
        
        /* Рисование прямоугольника */
        Rect rect = {100, 100, 200, 150};
        graphics_draw_rect(rect, COLOR_PRIMARY, true);
        
        /* Рисование круга */
        graphics_draw_circle(400, 300, 50, COLOR_ACCENT, true);
        
        /* Рисование текста */
        graphics_draw_text("Hello, OI UI!", 150, 400, COLOR_TEXT);
        
        /* Обновление экрана */
        graphics_present();
    }
    
    graphics_quit();
    return 0;
}
```

## Пример 5: Создание UI элементов

```c
#include "ui.h"
#include "graphics.h"

int main() {
    graphics_init(1080, 1920, "UI Demo");
    ui_init();
    
    Screen* screen = ui_create_screen("Demo Screen");
    screen->bg_color = COLOR_BACKGROUND;
    
    /* Кнопка */
    UIElement* btn = ui_create_button(100, 100, 200, 50, "Button");
    ui_add_element(screen, btn);
    
    /* Метка */
    UIElement* lbl = ui_create_label(100, 200, "Label");
    ui_add_element(screen, lbl);
    
    /* Иконка */
    UIElement* icon = ui_create_icon(100, 300, 100, "📱");
    ui_add_element(screen, icon);
    
    /* Слайдер */
    UIElement* slider = ui_create_slider(100, 450, 300, 0, 100);
    ui_add_element(screen, slider);
    
    /* Переключатель */
    UIElement* toggle = ui_create_toggle(100, 550, true);
    ui_add_element(screen, toggle);
    
    ui_show_screen(screen);
    
    return 0;
}
```

## Пример 6: Обработка сенсорного ввода

```c
#include "ui.h"
#include "graphics.h"
#include <SDL2/SDL.h>

void on_touch(int x, int y) {
    printf("Touch at: %d, %d\n", x, y);
}

int main() {
    graphics_init(1080, 1920, "Touch Demo");
    ui_init();
    
    Screen* screen = ui_create_screen("Touch Screen");
    screen->on_touch = on_touch;
    ui_show_screen(screen);
    
    bool running = true;
    SDL_Event event;
    
    while (running) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    running = false;
                    break;
                
                case SDL_FINGERDOWN: {
                    int x = (int)(event.tfinger.x * graphics_get_width());
                    int y = (int)(event.tfinger.y * graphics_get_height());
                    ui_handle_touch(x, y);
                    break;
                }
                
                case SDL_FINGERUP: {
                    int x = (int)(event.tfinger.x * graphics_get_width());
                    int y = (int)(event.tfinger.y * graphics_get_height());
                    ui_handle_release(x, y);
                    break;
                }
            }
        }
        
        graphics_clear(COLOR_BACKGROUND);
        ui_draw_screen(screen);
        graphics_present();
    }
    
    graphics_quit();
    return 0;
}
```

## Пример 7: Использование компонентов

```c
#include "components.h"
#include "graphics.h"

int main() {
    graphics_init(1080, 1920, "Components Demo");
    
    /* Создание статус-бара */
    StatusBar* statusbar = statusbar_create(50);
    
    /* Создание прогресс-бара */
    ProgressBar* progressbar = progressbar_create(100, 200, 400, 20, 100);
    progressbar_set_value(progressbar, 75);
    
    /* Создание уведомления */
    Notification* notif = notification_create("Hello, World!", 3);
    notification_show(notif);
    
    bool running = true;
    while (running) {
        graphics_clear(COLOR_BACKGROUND);
        
        /* Отрисовка компонентов */
        statusbar_draw(statusbar, graphics_get_width());
        progressbar_draw(progressbar);
        notification_draw(notif, graphics_get_width(), graphics_get_height());
        
        /* Обновление */
        notification_update(notif);
        
        graphics_present();
    }
    
    statusbar_free(statusbar);
    progressbar_free(progressbar);
    notification_free(notif);
    graphics_quit();
    
    return 0;
}
```

## Компиляция примеров

Для компиляции примеров используйте:

```bash
gcc -o example example.c src/kernel.c src/graphics.c src/ui.c \
    -I./include -lSDL2 -lSDL2_ttf -lSDL2_image -lm
```

Или добавьте файлы примеров в `CMakeLists.txt`:

```cmake
add_executable(example_1 examples/example1.c ${SOURCES})
target_link_libraries(example_1 ${SDL2_LIBRARIES} ${SDL2_TTF_LIBRARY} ${SDL2_IMAGE_LIBRARY} m)
```

## Дополнительные ресурсы

- **SDL2 документация**: https://wiki.libsdl.org/
- **SDL2_ttf**: https://www.libsdl.org/projects/SDL_ttf/
- **SDL2_image**: https://www.libsdl.org/projects/SDL_image/
