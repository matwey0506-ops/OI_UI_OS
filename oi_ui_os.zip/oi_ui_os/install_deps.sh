#!/bin/bash

# OI UI OS - Dependency Installation Script
# Автоматическая установка зависимостей для различных ОС

set -e

echo "========================================"
echo "OI UI Operating System - Setup Script"
echo "========================================"
echo ""

# Определение ОС
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    if [ -f /etc/debian_version ]; then
        # Debian/Ubuntu
        echo "[*] Detected: Debian/Ubuntu"
        echo "[*] Installing dependencies..."
        sudo apt-get update
        sudo apt-get install -y \
            libsdl2-dev \
            libsdl2-ttf-dev \
            libsdl2-image-dev \
            cmake \
            build-essential \
            git
        echo "[✓] Dependencies installed!"
        
    elif [ -f /etc/redhat-release ]; then
        # Fedora/RHEL/CentOS
        echo "[*] Detected: Fedora/RHEL/CentOS"
        echo "[*] Installing dependencies..."
        sudo dnf install -y \
            SDL2-devel \
            SDL2_ttf-devel \
            SDL2_image-devel \
            cmake \
            gcc \
            gcc-c++ \
            make \
            git
        echo "[✓] Dependencies installed!"
        
    elif [ -f /etc/arch-release ]; then
        # Arch Linux
        echo "[*] Detected: Arch Linux"
        echo "[*] Installing dependencies..."
        sudo pacman -S --noconfirm \
            sdl2 \
            sdl2_ttf \
            sdl2_image \
            cmake \
            base-devel \
            git
        echo "[✓] Dependencies installed!"
    else
        echo "[!] Unknown Linux distribution"
        echo "[!] Please install SDL2, SDL2_ttf, SDL2_image, CMake manually"
        exit 1
    fi
    
elif [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    echo "[*] Detected: macOS"
    
    # Проверка Homebrew
    if ! command -v brew &> /dev/null; then
        echo "[!] Homebrew not found. Installing..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    fi
    
    echo "[*] Installing dependencies..."
    brew install \
        sdl2 \
        sdl2_ttf \
        sdl2_image \
        cmake \
        git
    echo "[✓] Dependencies installed!"
    
elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
    # Windows (MSYS2/Cygwin)
    echo "[*] Detected: Windows (MSYS2/Cygwin)"
    echo "[!] Please install SDL2, CMake manually or use vcpkg"
    echo "[*] Recommended: https://github.com/microsoft/vcpkg"
    exit 1
else
    echo "[!] Unknown operating system"
    exit 1
fi

echo ""
echo "========================================"
echo "Setup Complete!"
echo "========================================"
echo ""
echo "Next steps:"
echo "1. cd /home/ubuntu/oi_ui_os"
echo "2. make build"
echo "3. make run"
echo ""
