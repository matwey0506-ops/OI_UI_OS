# OI UI OS - Руководство по разработке

## Архитектура системы

OI UI OS состоит из нескольких слоёв:

```
┌─────────────────────────────────┐
│   Applications (Приложения)     │
├─────────────────────────────────┤
│   UI Framework (UI фреймворк)   │
├─────────────────────────────────┤
│   Graphics Server (Графика)     │
├─────────────────────────────────┤
│   Kernel (Ядро ОС)              │
├─────────────────────────────────┤
│   Hardware Abstraction Layer    │
├─────────────────────────────────┤
│   SDL2 / System Libraries       │
└─────────────────────────────────┘
```

## Слои системы

### 1. Kernel Layer (kernel.c, kernel.h)

Отвечает за:
- Управление процессами
- Управление памятью
- Информацию о системе
- Управление устройством

**Основные функции:**
```c
void kernel_init();
SystemInfo* kernel_get_system_info();
DeviceInfo* kernel_get_device_info();
uint32_t kernel_create_process(const char* name);
void kernel_kill_process(uint32_t pid);
```

### 2. Graphics Layer (graphics.c, graphics.h)

Отвечает за:
- Инициализацию SDL2
- Рисование примитивов
- Работу с текстом
- Работу с текстурами

**Основные функции:**
```c
bool graphics_init(int width, int height, const char* title);
void graphics_clear(Color color);
void graphics_draw_rect(Rect rect, Color color, bool filled);
void graphics_draw_circle(int x, int y, int radius, Color color, bool filled);
void graphics_draw_text(const char* text, int x, int y, Color color);
```

### 3. UI Framework Layer (ui.c, ui.h)

Отвечает за:
- Создание UI элементов
- Управление экранами
- Обработку событий
- Отрисовку интерфейса

**Основные функции:**
```c
Screen* ui_create_screen(const char* name);
UIElement* ui_create_button(int x, int y, int w, int h, const char* label);
void ui_add_element(Screen* screen, UIElement* element);
void ui_show_screen(Screen* screen);
void ui_handle_touch(int x, int y);
```

### 4. Application Layer

Приложения используют UI Framework для создания интерфейса.

## Создание нового приложения

### Шаг 1: Создание файла приложения

```c
// src/my_app.c
#include "ui.h"
#include "graphics.h"
#include "kernel.h"

Screen* my_app_screen = NULL;

void my_app_on_show() {
    printf("[MY_APP] Application started\n");
}

void my_app_on_hide() {
    printf("[MY_APP] Application stopped\n");
}

void my_app_on_touch(int x, int y) {
    printf("[MY_APP] Touch at: %d, %d\n", x, y);
}

void my_app_on_update() {
    kernel_update_system_info();
}

Screen* my_app_create() {
    my_app_screen = ui_create_screen("My App");
    my_app_screen->bg_color = COLOR_BACKGROUND;
    my_app_screen->on_show = my_app_on_show;
    my_app_screen->on_hide = my_app_on_hide;
    my_app_screen->on_touch = my_app_on_touch;
    my_app_screen->on_update = my_app_on_update;
    
    // Добавление элементов
    UIElement* btn = ui_create_button(100, 100, 200, 50, "Click Me");
    ui_add_element(my_app_screen, btn);
    
    return my_app_screen;
}
```

### Шаг 2: Добавление заголовочного файла

```c
// include/my_app.h
#ifndef MY_APP_H
#define MY_APP_H

#include "ui.h"

Screen* my_app_create();

#endif
```

### Шаг 3: Интеграция в main.c

```c
// src/main.c
#include "my_app.h"

Screen* g_my_app_screen = NULL;

int main() {
    // ... инициализация ...
    
    g_my_app_screen = my_app_create();
    
    // ... главный цикл ...
}
```

### Шаг 4: Обновление CMakeLists.txt

```cmake
set(SOURCES
    src/main.c
    src/kernel.c
    src/graphics.c
    src/ui.c
    src/my_app.c
    # ... остальные файлы ...
)
```

## Работа с UI элементами

### Создание кнопки

```c
UIElement* btn = ui_create_button(x, y, width, height, "Label");
btn->on_click = button_clicked_handler;
ui_add_element(screen, btn);
```

### Создание метки

```c
UIElement* lbl = ui_create_label(x, y, "Text");
ui_add_element(screen, lbl);
```

### Создание иконки

```c
UIElement* icon = ui_create_icon(x, y, size, "emoji");
ui_add_element(screen, icon);
```

### Создание слайдера

```c
UIElement* slider = ui_create_slider(x, y, width, min_val, max_val);
slider->on_click = slider_changed_handler;
ui_add_element(screen, slider);
```

### Создание переключателя

```c
UIElement* toggle = ui_create_toggle(x, y, initial_state);
toggle->on_click = toggle_changed_handler;
ui_add_element(screen, toggle);
```

## Обработка событий

### Обработка касания

```c
void my_touch_handler(int x, int y) {
    printf("Touched at: %d, %d\n", x, y);
}

screen->on_touch = my_touch_handler;
```

### Обработка клика кнопки

```c
void button_clicked(UIElement* elem) {
    printf("Button clicked: %s\n", elem->label);
}

btn->on_click = button_clicked;
```

## Работа с цветами

### Использование предопределённых цветов

```c
Color primary = COLOR_PRIMARY;      // Синий
Color secondary = COLOR_SECONDARY;  // Зелёный
Color accent = COLOR_ACCENT;        // Оранжевый
Color background = COLOR_BACKGROUND; // Светло-серый
Color text = COLOR_TEXT;            // Тёмно-серый
Color border = COLOR_BORDER;        // Серый
```

### Создание пользовательского цвета

```c
Color my_color = color_make(255, 128, 0, 255); // Оранжевый
```

## Работа с графикой

### Рисование прямоугольника

```c
Rect rect = {x, y, width, height};
graphics_draw_rect(rect, COLOR_PRIMARY, true);  // Заполненный
graphics_draw_rect(rect, COLOR_BORDER, false);  // Контур
```

### Рисование круга

```c
graphics_draw_circle(x, y, radius, COLOR_PRIMARY, true);  // Заполненный
graphics_draw_circle(x, y, radius, COLOR_BORDER, false);  // Контур
```

### Рисование линии

```c
graphics_draw_line(x1, y1, x2, y2, COLOR_TEXT, thickness);
```

### Рисование текста

```c
graphics_draw_text("Hello, World!", x, y, COLOR_TEXT);
```

## Работа с процессами

### Создание процесса

```c
uint32_t pid = kernel_create_process("MyApp");
```

### Завершение процесса

```c
kernel_kill_process(pid);
```

### Пауза процесса

```c
kernel_pause_process(pid);
```

### Возобновление процесса

```c
kernel_resume_process(pid);
```

## Получение системной информации

### Информация о системе

```c
SystemInfo* sys_info = kernel_get_system_info();
printf("Uptime: %u seconds\n", sys_info->uptime_seconds);
printf("Battery: %.1f%%\n", sys_info->battery_level);
printf("CPU: %u%%\n", sys_info->cpu_usage);
```

### Информация об устройстве

```c
DeviceInfo* dev_info = kernel_get_device_info();
printf("Screen: %dx%d\n", dev_info->screen_width, dev_info->screen_height);
printf("DPI: %d\n", dev_info->screen_dpi);
printf("Touchscreen: %s\n", dev_info->touchscreen ? "Yes" : "No");
```

## Отладка

### Логирование

```c
printf("[MODULE] Message\n");
printf("[MY_APP] Value: %d\n", value);
```

### Компиляция с отладочной информацией

```bash
cmake -DCMAKE_BUILD_TYPE=Debug ..
make
gdb ./build/oi_ui_os
```

## Оптимизация

### Компиляция с оптимизацией

```bash
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j4
```

### Профилирование

```bash
valgrind --leak-check=full ./build/oi_ui_os
```

## Расширение функциональности

### Добавление новых компонентов

1. Создайте заголовочный файл в `include/`
2. Создайте реализацию в `src/`
3. Добавьте в `CMakeLists.txt`
4. Включите в `main.c`

### Добавление новых экранов

1. Создайте файл экрана в `src/`
2. Реализуйте функции `on_show`, `on_hide`, `on_touch`, `on_update`
3. Создайте функцию `create()`
4. Интегрируйте в `main.c`

## Лучшие практики

1. **Используйте понятные имена**: `button_ok`, `label_title`, `icon_settings`
2. **Документируйте код**: Добавляйте комментарии для сложной логики
3. **Проверяйте NULL**: Всегда проверяйте указатели перед использованием
4. **Освобождайте ресурсы**: Используйте `free()` для выделенной памяти
5. **Обрабатывайте ошибки**: Проверяйте возвращаемые значения функций
6. **Тестируйте**: Создавайте простые тесты для новых функций
7. **Оптимизируйте**: Профилируйте и оптимизируйте узкие места

## Ссылки

- [SDL2 Wiki](https://wiki.libsdl.org/)
- [SDL2 API Reference](https://wiki.libsdl.org/CategoryAPI)
- [C Programming Guide](https://en.cppreference.com/w/c)
